# VirtuOrça — Arquitetura Unificada

## Decisão de arquitetura

O VirtuOrça será um produto com **uma base funcional compartilhada** e duas formas de uso:

- **Desktop Windows:** Electron + SQLite local, funcionando sem internet.
- **Web:** aplicação web + PostgreSQL/Supabase, acessível pelo navegador.
- **Núcleo compartilhado:** regras de orçamento, cálculos, validações e modelos de dados em `packages/core`.

A interface aprovada da versão 3.0 fica preservada em `legacy/desktop` como referência funcional. Ela não será sobrescrita.

## Princípios obrigatórios

1. Nenhum orçamento é removido ou substituído durante migração sem cópia verificável.
2. Uma gravação só pode ser apresentada como concluída depois da confirmação do banco.
3. Toda alteração relevante recebe identificador, data, autor/dispositivo e revisão.
4. Desktop funciona offline e mantém fila de sincronização.
5. Sincronização nunca usa "última gravação vence" silenciosamente.
6. Conflitos geram cópias/versões para revisão humana.
7. Backup local e backup externo são camadas diferentes.
8. Restauração deve ser testada, não apenas criada.
9. Exportações Excel/PDF são artefatos derivados; o banco é a fonte dos dados.
10. A interface rosa da marca fica no aplicativo; exportações mantêm identidade neutra, conforme decisão do produto.

## Modelo de armazenamento

### Desktop
- SQLite em diretório de dados do usuário, nunca dentro da pasta de instalação.
- WAL, `synchronous=FULL`, transações.
- Revisões imutáveis por orçamento.
- Backup consistente usando a API de backup do SQLite.
- Cópia adicional em unidade externa ou nuvem configurada.

### Web
- PostgreSQL gerenciado.
- RLS por empresa e usuário.
- Histórico de revisões e trilha de auditoria.
- Backups do provedor + exportação independente.

### Sincronização
Cada alteração recebe `change_id`, `project_id`, `base_revision`, `device_id`, `created_at` e payload.
O servidor aceita uma alteração se a revisão-base ainda for atual. Se não for, cria conflito sem apagar nenhum dos lados.
A fila local só marca o item como sincronizado após confirmação do servidor.

## Estado desta entrega

Este pacote estabelece a arquitetura e os contratos iniciais. Ainda **não** é um aplicativo final nem conclui a migração do HTML legado para o núcleo compartilhado. A integração deve ser feita por etapas e testada com cópias dos dados.
