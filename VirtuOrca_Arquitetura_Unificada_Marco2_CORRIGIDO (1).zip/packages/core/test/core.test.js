import test from 'node:test';
import assert from 'node:assert/strict';
import { parseDecimalBR, calculateUnitWithBDI, calculateLineTotal, calculateBudgetTotal } from '../src/index.js';

test('parse decimal brasileiro',()=>assert.equal(parseDecimalBR('1.234,56'),1234.56));
test('BDI',()=>assert.equal(calculateUnitWithBDI(100,25),125));
test('total da linha',()=>assert.equal(calculateLineTotal(2,125),250));
test('total ignora cabeçalho macroitem',()=>assert.equal(calculateBudgetTotal([
 {kind:'macro'}, {kind:'servico',sem:100,com:100,quantidade:2,bdiCom:25}
]),250));
