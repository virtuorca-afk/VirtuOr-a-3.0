// Núcleo compartilhado do VirtuOrça.
// Deve permanecer independente de Electron, navegador e Supabase.

export function parseDecimalBR(value) {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  let s = String(value).trim().replace(/R\$\s?/g, '').replace(/\s/g, '');
  if (!s || s === '-' || s === '—') return null;
  if (s.includes(',') && s.includes('.')) s = s.replace(/\./g, '').replace(',', '.');
  else if (s.includes(',')) s = s.replace(',', '.');
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export function truncateMoney(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.trunc((n + Number.EPSILON) * 100) / 100;
}

export function calculateUnitWithBDI(basePrice, bdiPercent) {
  const base = Number(basePrice);
  const bdi = Number(bdiPercent);
  if (!Number.isFinite(base) || !Number.isFinite(bdi)) {
    throw new TypeError('Preço-base e BDI precisam ser números válidos.');
  }
  return truncateMoney(base * (1 + bdi / 100));
}

export function calculateLineTotal(quantity, unitPrice) {
  const q = Number(quantity);
  const p = Number(unitPrice);
  if (!Number.isFinite(q) || !Number.isFinite(p)) {
    throw new TypeError('Quantidade e preço unitário precisam ser números válidos.');
  }
  return truncateMoney(q * p);
}

export function calculateBudgetTotal(items, regime = 'com') {
  if (!Array.isArray(items)) throw new TypeError('Itens do orçamento inválidos.');
  return truncateMoney(items.reduce((sum, item) => {
    if (item?.kind === 'macro') return sum;
    const base = regime === 'sem' ? item.sem : item.com;
    const bdi = regime === 'sem'
      ? (item.bdiSem ?? item.bdi ?? 0)
      : (item.bdiCom ?? item.bdi ?? 0);
    const unit = calculateUnitWithBDI(Number(base) || 0, Number(bdi) || 0);
    return sum + calculateLineTotal(Number(item.quantidade) || 0, unit);
  }, 0));
}
