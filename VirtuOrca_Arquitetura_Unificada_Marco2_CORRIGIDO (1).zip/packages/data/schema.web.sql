-- PostgreSQL/Supabase. Ativar RLS e criar policies antes de expor dados.
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.company_members (
  company_id uuid not null references public.companies(id) on delete restrict,
  user_id uuid not null references auth.users(id) on delete restrict,
  role text not null check (role in ('owner','admin','editor','viewer')),
  created_at timestamptz not null default now(),
  primary key(company_id, user_id)
);

create table if not exists public.projects (
  id uuid primary key,
  company_id uuid not null references public.companies(id) on delete restrict,
  payload jsonb not null,
  revision bigint not null default 1,
  updated_at timestamptz not null default now(),
  checksum text not null
);

create table if not exists public.project_revisions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete restrict,
  revision bigint not null,
  payload jsonb not null,
  checksum text not null,
  created_at timestamptz not null default now(),
  reason text not null,
  unique(project_id, revision)
);

create table if not exists public.sync_changes (
  change_id uuid primary key,
  project_id uuid not null references public.projects(id) on delete restrict,
  device_id text not null,
  base_revision bigint not null,
  payload jsonb not null,
  status text not null check (status in ('accepted','conflict','rejected')),
  created_at timestamptz not null default now()
);

alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.projects enable row level security;
alter table public.project_revisions enable row level security;
alter table public.sync_changes enable row level security;

-- Policies RLS específicas serão criadas junto com as funções de acesso.
-- Não liberar acesso público antes de implementar e testar as policies.
