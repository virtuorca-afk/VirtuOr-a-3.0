# Decisões técnicas — VirtuOrça

## 1. Estratégia
Monorepo com:
- `apps/desktop`: Electron para Windows.
- `apps/web`: aplicação web.
- `packages/core`: regras de negócio independentes de interface e banco.
- `packages/data`: esquemas e contratos de persistência.
- `legacy/desktop`: versão de referência congelada.

## 2. Fonte de verdade
- Offline: SQLite é a fonte de verdade local.
- Online: PostgreSQL é a fonte de verdade compartilhada.
- Ao sincronizar, o servidor confirma a revisão recebida e devolve a revisão canônica.
- Nenhuma sincronização pode sobrescrever revisão divergente sem resolução explícita.

## 3. Proteção contra perda
- Transação atômica por operação.
- Checksum SHA-256 dos payloads.
- Revisões imutáveis.
- Backup consistente com verificação de integridade.
- Rotina de restauração validada.
- Cópia externa obrigatória antes de considerar a proteção completa.
- Migração com contagem de registros, hash e relatório de diferenças.

## 4. Estratégia de migração da versão 3.0
1. Congelar cópia da versão aprovada.
2. Fazer inventário dos dados e operações de gravação.
3. Implementar adaptador de persistência sem alterar cálculos.
4. Ler dados antigos em modo somente leitura.
5. Importar para SQLite em transação.
6. Comparar quantidade, identificadores e totais.
7. Testar restauração.
8. Só depois habilitar escrita no novo banco.
9. Repetir o processo para a sincronização web.

## 5. Segurança
- Credenciais Supabase nunca ficam no cliente como segredo.
- RLS em todas as tabelas de empresa.
- Papéis e permissões validados no servidor.
- Tokens e chaves fora do código-fonte.
- Logs sem dados sensíveis desnecessários.
