# Contrato de sincronização Desktop ↔ Web

## Estrutura mínima de uma alteração
```json
{
  "change_id": "UUID",
  "project_id": "UUID",
  "device_id": "identificador-do-dispositivo",
  "base_revision": 12,
  "created_at": "ISO-8601",
  "payload": {},
  "checksum": "sha256"
}
```

## Regras
- `change_id` é idempotente: repetir a mesma requisição não duplica alteração.
- Servidor valida empresa, usuário, papel e revisão-base.
- Se `base_revision` coincide com a revisão atual, servidor cria revisão seguinte e confirma.
- Se não coincide, servidor marca conflito e preserva ambas as versões.
- Cliente só remove da fila após confirmação inequívoca.
- Falha de rede mantém alteração pendente localmente.
- Conflitos exigem comparação e escolha explícita; nunca sobrescrever silenciosamente.

## Casos de teste
1. Desktop offline cria orçamento e sincroniza quando voltar a conexão.
2. Web e Desktop alteram o mesmo orçamento offline: conflito detectado.
3. Repetição de requisição não duplica a revisão.
4. Queda de conexão durante resposta não perde a alteração local.
5. Restauração de revisão antiga cria nova revisão, sem apagar histórico.
