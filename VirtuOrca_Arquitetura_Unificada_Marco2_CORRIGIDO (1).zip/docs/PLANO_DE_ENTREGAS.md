# Plano de entregas

- [x] Preservar HTML legado aprovado como referência.
- [x] Definir arquitetura compartilhada Desktop/Web.
- [x] Criar primeiro núcleo comum de cálculos (versão inicial).
- [x] Definir esquemas SQLite e PostgreSQL.
- [x] Definir protocolo de sincronização sem sobrescrita silenciosa.
- [ ] Integrar interface atual ao adaptador SQLite e remover gravações concorrentes.
- [ ] Migrar dados de teste com relatório de integridade.
- [ ] Criar testes automatizados de cálculo comparando núcleo e versão legada.
- [ ] Implementar RLS e autenticação no Web.
- [ ] Implementar fila de sincronização e resolução de conflitos.
- [ ] Implementar cópia externa e ensaios de restauração.
- [ ] Homologar com orçamentos de teste antes de uso profissional.
