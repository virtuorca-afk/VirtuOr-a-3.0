const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('virtuOrcaDesktop', {
  sqliteSaveProject: (project, reason) => ipcRenderer.invoke('virtuorca:sqlite-save-project', project, reason),
  sqliteSaveMany: (projects) => ipcRenderer.invoke('virtuorca:sqlite-save-many', projects),
  sqliteLoadProject: (id) => ipcRenderer.invoke('virtuorca:sqlite-load-project', id),
  sqliteListProjects: () => ipcRenderer.invoke('virtuorca:sqlite-list-projects'),
  sqliteListRevisions: (id) => ipcRenderer.invoke('virtuorca:sqlite-list-revisions', id),
  sqliteRestoreRevision: (id) => ipcRenderer.invoke('virtuorca:sqlite-restore-revision', id),
  backupNow: () => ipcRenderer.invoke('virtuorca:backup-now'),
  openBackupFolder: () => ipcRenderer.invoke('virtuorca:backup-folder'),
  integrityCheck: () => ipcRenderer.invoke('virtuorca:integrity-check'),
  onBackupError: (callback) => ipcRenderer.on('virtuorca:backup-error', (_event, message) => callback(message))
});
