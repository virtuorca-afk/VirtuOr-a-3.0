const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const path = require('path');
const VirtuOrcaStorage = require('./storage');

let win;
let backupTimer;
let storage;
const BACKUP_INTERVAL_MS = 15 *  60 * 1000;

function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 940, minWidth: 1100, minHeight: 700,
    title: 'VirtuOrça',
    icon: path.join(__dirname, 'assets', 'virtuorca.ico'),
    backgroundColor: '#faf8fa',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  win.on('close', async (event) => {
    if (win.__closingApproved) return;
    event.preventDefault();
    try {
      const result = await storage.createBackup('ao_fechar');
      if (!result.ok) throw new Error('O backup não foi confirmado.');
      win.__closingApproved = true;
      win.close();
    } catch (error) {
      const choice = await dialog.showMessageBox(win, {
        type: 'warning',
        title: 'Backup não confirmado',
        message: 'Não foi possível validar o backup de segurança.',
        detail: `${error.message}\n\nRecomendamos tentar novamente antes de fechar.`,
        buttons: ['Tentar novamente', 'Fechar mesmo assim'],
        defaultId: 0,
        cancelId: 0
      });
      if (choice.response === 1) {
        const confirm = await dialog.showMessageBox(win, {
          type: 'warning',
          title: 'Confirmação de fechamento',
          message: 'Fechar sem backup validado?',
          detail: 'Os dados já gravados no SQLite permanecem no computador, mas a cópia externa não foi confirmada.',
          buttons: ['Voltar', 'Fechar'],
          defaultId: 0,
          cancelId: 0
        });
        if (confirm.response === 1) {
          win.__closingApproved = true;
          win.close();
        }
      }
    }
  });
}

app.whenReady().then(() => {
  app.setAppUserModelId('br.com.virtuorca.app');
  storage = new VirtuOrcaStorage(app.getPath('userData'), app.getPath('documents'));
  createWindow();
  backupTimer = setInterval(async () => {
    try { await storage.createBackup('automatico'); }
    catch (e) { if (win && !win.isDestroyed()) win.webContents.send('virtuorca:backup-error', e.message); }
  }, BACKUP_INTERVAL_MS);
});

ipcMain.handle('virtuorca:sqlite-save-project', (_event, project, reason) => storage.saveProject(project, reason || 'autosave'));
ipcMain.handle('virtuorca:sqlite-save-many', (_event, projects) => storage.saveMany(projects));
ipcMain.handle('virtuorca:sqlite-load-project', (_event, id) => storage.loadProject(id));
ipcMain.handle('virtuorca:sqlite-list-projects', () => storage.listProjects());
ipcMain.handle('virtuorca:sqlite-list-revisions', (_event, id) => storage.listRevisions(id));
ipcMain.handle('virtuorca:sqlite-restore-revision', (_event, id) => storage.restoreRevision(id));
ipcMain.handle('virtuorca:backup-now', () => storage.createBackup('manual'));
ipcMain.handle('virtuorca:backup-folder', async () => {
  const folder = path.join(app.getPath('documents'), 'VirtuOrça', 'Backups');
  return shell.openPath(folder);
});
ipcMain.handle('virtuorca:integrity-check', () => ({ result: storage.integrityCheck() }));

app.on('before-quit', () => {
  if (backupTimer) clearInterval(backupTimer);
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
