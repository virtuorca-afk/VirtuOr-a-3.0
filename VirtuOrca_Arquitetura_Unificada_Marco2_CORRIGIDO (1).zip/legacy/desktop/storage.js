// Persistência local do VirtuOrça — SQLite com WAL, transações e revisões.
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class VirtuOrcaStorage {
  constructor(userDataPath, documentsPath) {
    this.root = path.join(userDataPath, 'dados');
    this.backupRoot = path.join(documentsPath, 'VirtuOrça', 'Backups');
    fs.mkdirSync(this.root, { recursive: true });
    fs.mkdirSync(this.backupRoot, { recursive: true });
    this.dbPath = path.join(this.root, 'virtuorca.sqlite');
    this.db = new Database(this.dbPath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('synchronous = FULL');
    this.db.pragma('foreign_keys = ON');
    this.db.pragma('busy_timeout = 5000');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        payload TEXT NOT NULL,
        updated_at INTEGER NOT NULL,
        checksum TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS revisions (
        id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL,
        payload TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        checksum TEXT NOT NULL,
        reason TEXT NOT NULL,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
      );
      CREATE INDEX IF NOT EXISTS idx_revisions_project_date
        ON revisions(project_id, created_at DESC);
      CREATE TABLE IF NOT EXISTS app_meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );
    `);
    this.saveProjectStmt = this.db.prepare(`
      INSERT INTO projects(id,payload,updated_at,checksum) VALUES(@id,@payload,@updated_at,@checksum)
      ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at, checksum=excluded.checksum
    `);
    this.latestRevisionStmt = this.db.prepare(
      'SELECT created_at FROM revisions WHERE project_id=? ORDER BY created_at DESC LIMIT 1'
    );
  }
  checksum(payload) {
    return crypto.createHash('sha256').update(payload, 'utf8').digest('hex');
  }
  saveProject(project, reason = 'autosave', forceRevision = false) {
    if (!project || !project.id) throw new Error('Projeto sem identificador; gravação recusada.');
    const payload = JSON.stringify(project);
    const now = Date.now();
    const checksum = this.checksum(payload);
    const tx = this.db.transaction(() => {
      this.saveProjectStmt.run({ id: String(project.id), payload, updated_at: now, checksum });
      const latest = this.latestRevisionStmt.get(String(project.id));
      // Histórico automático limitado a uma revisão a cada 5 minutos; ações manuais podem forçar revisão.
      if (forceRevision || !latest || now - latest.created_at >= 5 * 60 * 1000) {
        this.db.prepare(`INSERT INTO revisions(id,project_id,payload,created_at,checksum,reason)
          VALUES(?,?,?,?,?,?)`).run(crypto.randomUUID(), String(project.id), payload, now, checksum, reason);
      }
    });
    tx();
    return { ok: true, projectId: String(project.id), savedAt: now, checksum };
  }
  saveMany(projects, reason = 'autosave') {
    if (!Array.isArray(projects)) throw new Error('Lista de projetos inválida.');
    const tx = this.db.transaction(() => projects.map(p => this.saveProject(p, reason, false)));
    return tx();
  }
  loadProject(id) {
    const row = this.db.prepare('SELECT payload,checksum,updated_at FROM projects WHERE id=?').get(String(id));
    if (!row) return null;
    if (this.checksum(row.payload) !== row.checksum) throw new Error('A verificação de integridade do orçamento falhou. O registro não será carregado.');
    return { project: JSON.parse(row.payload), savedAt: row.updated_at, checksum: row.checksum };
  }
  listProjects() {
    return this.db.prepare('SELECT id,updated_at FROM projects ORDER BY updated_at DESC').all();
  }
  listRevisions(id) {
    return this.db.prepare('SELECT id,created_at,reason,checksum FROM revisions WHERE project_id=? ORDER BY created_at DESC').all(String(id));
  }
  restoreRevision(revisionId) {
    const row = this.db.prepare('SELECT project_id,payload,checksum FROM revisions WHERE id=?').get(String(revisionId));
    if (!row) throw new Error('Versão anterior não encontrada.');
    if (this.checksum(row.payload) !== row.checksum) throw new Error('A versão anterior está corrompida; restauração cancelada.');
    const project = JSON.parse(row.payload);
    this.saveProject(project, 'antes_da_restauracao', true);
    return this.saveProject(project, 'restauracao', true);
  }
  async createBackup(label = 'automatico') {
    // better-sqlite3 backup API captura um estado consistente mesmo com WAL ativo.
    const safeLabel = String(label).replace(/[^a-z0-9_-]/gi, '_');
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const target = path.join(this.backupRoot, `VirtuOrca_${safeLabel}_${stamp}.sqlite`);
    await this.db.backup(target);
    const verify = new Database(target, { readonly: true, fileMustExist: true });
    try {
      const result = verify.pragma('integrity_check', { simple: true });
      if (result !== 'ok') throw new Error(`Backup reprovado no integrity_check: ${result}`);
      const count = verify.prepare('SELECT COUNT(*) AS n FROM projects').get().n;
      if (!fs.statSync(target).size) throw new Error('Backup vazio.');
      return { ok: true, path: target, projects: count, bytes: fs.statSync(target).size };
    } finally {
      verify.close();
    }
  }
  integrityCheck() {
    return this.db.pragma('integrity_check', { simple: true });
  }
  close() { if (this.db && this.db.open) this.db.close(); }
}
module.exports = VirtuOrcaStorage;
